import React from 'react';
import Products from './components/ProductContainer';

function App(props) {
    return (
        <div>
            <Products />
        </div>
    );
}

export default App;